<h3>Welcome to Subbo</h3>

<blockquote>
    To start using our application please click menu button at the bottom of the right corner <br/>
    You can create your own creation into album
</blockquote>