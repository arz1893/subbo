@extends('layouts.app')

@section('content')
    <div class="container">
        <h3>You can contact us at</h3>
    </div>


    @include('footer')
@endsection