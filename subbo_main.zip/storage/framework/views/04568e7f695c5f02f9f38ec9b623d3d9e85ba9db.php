<footer class="page-footer white">
    <div class="container">
        <div class="row">
            <div class="col l6 s12">
                <h5 class="black-text">Footer Content</h5>
                <p class="black-text">You can use rows and columns here to organize your footer content.</p>
            </div>
            <div class="col l4 offset-l2 s12">
                <h5 class="black-text">Pages</h5>
                <ul>
                    <li><a class="black-text" href="<?php echo e(url('/about')); ?>">About</a></li>
                    <li><a class="black-text" href="<?php echo e(url('/contact')); ?>">Contact</a></li>
                    <li><a class="black-text" href="#!">FAQ</a></li>
                    <li><a class="black-text" href="#!">Subscribe</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-copyright black-text">
        <div class="container">
            © <?php echo date("Y") ?> All Rights reserved
        </div>
    </div>
</footer>