<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 5%">
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:site" content="http://subboapp2.esy.es/showcatalog/<?php echo e($album->id); ?>">
        <meta name="twitter:title" content="<?php echo e($album->title); ?>">
        <meta name="twitter:description" content="<?php echo e($album->description); ?>">

        <?php if(\Session::has('info')): ?>
            <div class="chip green lighten-1 white-text center" style="width: 100%;">
                Success! <?php echo e(\Session::get('info')); ?>

                <i class="close material-icons">close</i>
            </div>
        <?php elseif(\Session::has('error')): ?>
            <div class="chip red lighten-1 white-text center" style="width: 100%;">
                Success! <?php echo e(\Session::get('error')); ?>

                <i class="close material-icons">close</i>
            </div>
        <?php endif; ?>

        <!-- Page Contents -->
        <div class="page animated fadeinup">

            <!-- Hero Header -->
            <div class="hero-header animated fadein">
                <!-- Slider -->
                <div class="swiper-container swiper-slider">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <a href="#!">
                                <?php $__currentLoopData = $imageThumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageThumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($imageThumbnail->id == $album->album_cover_id): ?>
                                        <div class="col s12 m4 l4">
                                            <img src="<?php echo e(asset($imageThumbnail->thumbnail_path)); ?>" width="100%">
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </a>
                        </div>
                    </div>
                    <!-- Add Pagination -->
                    <div class="swiper-pagination"></div>
                </div>
                <!-- End of Slider -->

                <!-- Floating Action Button -->
                <?php if($status == true): ?>
                    <a href="<?php echo e(route('show_download', $album)); ?>" class="btn grey" style="width: 100%">
                        Download <i class="fa fa-download" aria-hidden="true"></i>
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('show_payment', $album)); ?>" class="btn amber" style="width: 100%">
                        Purchase <i class="fa fa-cart-plus"></i>
                    </a>
                <?php endif; ?>
            </div>

            <ul class="collapsible" data-collapsible="accordion">
                <li>
                    <div class="collapsible-header"><i class="fa fa-question-circle-o"></i>Album's info</div>
                    <div class="collapsible-body">
                        <!-- Product Title -->
                        <div class="center-align p-20">
                            <?php if (! ($album->categories->isEmpty())): ?>
                                <ul>
                                    <?php $__currentLoopData = $album->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="chip">
                                            <img src="<?php echo e(asset('images/default/' . $category->image)); ?>">
                                            <?php echo e($category->category_name); ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            <h4 class="m-0"><strong><?php echo e($album->title); ?></strong></h4>
                            <h4><?php echo e($currency->code . " " .number_format( $album->price , 2 , ',', '.' )); ?></h4>
                            <p class="flow-text" style="text-align: justify;">
                                <span><b>Description: </b></span><br>
                                <?php echo e($album->description); ?>

                            </p>
                        </div>
                    </div>
                </li>
            </ul>

            <div class="row">
                <ul>
                    <?php $__currentLoopData = $imageThumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageThumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <img src="<?php echo e(asset($imageThumbnail->thumbnail_path)); ?>" class="col s4 m2 l2 image-thumbnails" height="75px">
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>