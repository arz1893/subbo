<div class="container" id="albumform-container">

    <div class="row">
        <div class="">
            <label for="title" class="form-label">Title</label>
            <?php echo e(Form::text(
                'title',
                null,
                    ['class' => 'validate',
                    'placeholder' => 'Your album title\'s here',
                    'id' => 'title',
                    'style' => 'margin-bottom: 5px;'])); ?>

        </div>
    </div>

    <div class="row">
        <div class="">
            <label for="description" class="form-label">Description</label>
            <?php echo e(Form::textarea(
                'description',
                 null,
                    ['class' => 'validate materialize-textarea',
                    'placeholder' => 'Your album description\'s here ',
                    'id' => 'description',
                    'style' => 'margin-bottom: -5px;']
                    )); ?>

        </div>
    </div>

    <div class="row" id="category_container" style="margin-top: 10px;">
        <label for="categoryList" class="form-label">Select Category</label>
        <select name="category_list[]" id="categoryList" multiple required>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        
    </div>

    <div class="row">
        <div class="">
            <label for="price" class="form-label">Price <span class="grey-text">(current currency : <?php echo e($currency->code); ?> / <?php echo e($currency->currency); ?>)</span></label>
            <?php echo Form::input(
                'number',
                'price',
                null,
                    ['class' => 'validate',
                     'step' => 'any',
                     'placeholder' => $currency->code,
                     'id' => 'price',
                     'style' => 'margin-bottom: 5px;']); ?>

        </div>
    </div>
</div>