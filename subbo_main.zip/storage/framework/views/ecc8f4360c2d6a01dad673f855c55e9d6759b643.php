<?php $__env->startSection('main'); ?>
    <div id="add_album_container" style="">
        <?php echo $__env->make('errors.errorlist', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::open(['action' => 'AlbumController@store', 'files' => true, 'id' => 'album-form']); ?>

            <?php echo e(Form::hidden('id', $album->id)); ?>

            <?php echo $__env->make('layouts.album.albumform', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::close(); ?>


        <div class="container" id="dropzone_container">
            <span style="font-size: 1.2em">Add Image</span> <br>
            <a class="waves-effect waves-light grey btn btn-add-image">
                <i class="fa fa-plus-square"></i>
            </a> <br> <br>

            <?php echo Form::open(['action' => ['AlbumController@uploadAllImages'], 'class' => 'dropzone', 'files' => true, 'id'=>'upload-image', 'style' => 'display:none']); ?>

                <?php echo e(Form::hidden('album_id', $album->id, ['id' => 'album_id'])); ?>

            <?php echo Form::close(); ?>


            <br>

            <div class="row">
                <button id="btnSubmitImage" type="button" class="btn-large waves-effect teal lighten-1" style="width: 100%;">
                    Create album
                </button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>