<?php $__env->startSection('main'); ?>

    <?php echo $__env->make('errors.errorlist', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::model($album, ['method' => 'PATCH', 'action' => ['AlbumController@update', $album]]); ?>

        <?php echo $__env->make('layouts.album.withoutupload', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>