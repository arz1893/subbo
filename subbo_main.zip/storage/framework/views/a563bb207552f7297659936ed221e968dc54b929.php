<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(\Illuminate\Support\Facades\Request::path() == 'home'): ?>
            <?php echo $__env->make('prolog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    </div>

    <?php echo $__env->yieldContent('main'); ?>

    <?php if(Route::currentRouteName() == 'album.index'): ?>
        <div class="fixed-action-btn">
            <a href="<?php echo e(route('create_album_first')); ?>" class="btn-floating btn-large waves-effect waves-light red darken-1">
                <i class="material-icons">add</i>
            </a>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>