<?php $__env->startSection('main'); ?>
    <div class="container">
        <h5>Your album list</h5>
        <hr>

        <table class="display" style="width: 100%" id="table-sold-album">
            <thead>
                <tr>
                    <th>No. </th>
                    <th>Image</th>
                    <th>Album's title</th>
                    <th>Price</th>
                    <th>Downloaded</th>
                </tr>
            </thead>
            <tbody>
                <?php $counter = 1; ?>
                <?php $__currentLoopData = $userAlbums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userAlbum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($counter); ?></td>
                        <td>
                            <?php $__currentLoopData = $imageThumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageThumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($imageThumbnail->id == $userAlbum->album_cover_id): ?>
                                    <a href="#!">
                                        <img src="<?php echo e(asset($imageThumbnail->thumbnail_path)); ?>" width="75" style="margin: 2%;">
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <a href="#!">
                                <?php echo e($userAlbum->title); ?>

                            </a>
                        </td>
                        <td><?php echo e($currency->code . " " . number_format( $userAlbum->price , 2 , '.', '.' )); ?></td>
                        <td>
                            <?php if(count($userAlbum->purchased_albums()->get()) != 0): ?>
                                <a href="<?php echo e(route('user_download', $userAlbum)); ?>">
                                    <?php echo e(count($userAlbum->purchased_albums()->get())); ?> times
                                </a>
                            <?php else: ?>
                                no one download it yet
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php $counter++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>