<?php $__env->startSection('content'); ?>
    <div id="panel1">
        <div class="center" style="padding-top: 15%;">
            <a href="<?php echo e(route('register')); ?>" class="btn waves-effect teal white-text darken-text-2">sign up for free</a> <br> <br>
            <span class="white-text">or </span> <a href="<?php echo e(route('login')); ?>" class="blue-text text-lighten-2">sign in</a>
        </div>
    </div>

    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>