<?php $__env->startSection('main'); ?>
    <?php echo $__env->make('errors.errorlist', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">
        <?php echo e(Form::open(['method' => 'PATCh', 'action' => ['UserController@addBankAccount', Auth::user()]])); ?>

            <div class="row">
                <div class="input-field">
                    <?php echo e(Form::label('bank_name', 'Bank Name : ')); ?>

                    <?php echo e(Form::text('bank_name', null, ['class' => ''])); ?>

                </div>
            </div>
            <div class="row">
                <div class="input-field">
                    <?php echo e(Form::label('account_number', 'Account Number : ')); ?>

                    <?php echo e(Form::text('account_number', null, ['class' => ''])); ?>

                </div>
            </div>
            <div class="row">
                <div class="input-field">
                    <?php echo e(Form::submit('add bank account', ['class' => 'btn blue lighten-2', 'style' => 'width: 100%'])); ?>

                </div>
            </div>
        <?php echo e(Form::close()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>