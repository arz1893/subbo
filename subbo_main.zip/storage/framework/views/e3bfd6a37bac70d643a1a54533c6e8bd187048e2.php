<?php $__env->startSection('main'); ?>
    <div class="center">
        <br/><br/>
        <?php if($user->provider_id != null): ?>
            <img src="https://graph.facebook.com/v2.8/<?php echo e($user->provider_id); ?>/picture?type=large"
                 width="150" height="150" id="profilePicture" class="circle">
        <?php elseif($user->avatar != null): ?>
            <img src="<?php echo e(asset('profile_picture/' . $user->avatar)); ?>"
                 width="150" height="150" id="profilePicture" class="circle">
        <?php else: ?>
            <img src="<?php echo e(asset('images/default/default-avatar.png')); ?>"
                 width="150" height="150" id="profilePicture" class="circle">
        <?php endif; ?>
        <h4><?php echo e($user->name); ?></h4>
    </div>

    <ul class="collapsible popout" data-collapsible="accordion">
        <li>
            <div class="collapsible-header">About <i class="fa fa-align-left" aria-hidden="true"></i></div>
            <div class="collapsible-body">
                <?php if(is_null($user->about)): ?>
                    <p align="justify">
                        you haven't fill your profile completely
                    </p>
                <?php else: ?>
                    <?php echo html_entity_decode(nl2br($user->about)); ?>

                <?php endif; ?>
            </div>
        </li>
        <li>
            <div class="collapsible-header"><i class="material-icons">contact_phone</i>Contact</div>
            <div class="collapsible-body">
                <a href="#!">E-mail creator</a> <br>
                <a href="#!">Call / send message to creator</a>
            </div>
        </li>
    </ul>

    <div class="row">
        <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col s12 m6 l4">
                <div class="card small z-depth-3">
                    <div class="card-image">
                        <?php if($album->album_cover_id == null): ?>
                            <a href="<?php echo e(route('showcase_album', $album->id)); ?>">
                                <img src="<?php echo e(asset('images/default/unknown.png')); ?>">
                            </a>
                        <?php else: ?>
                            <?php $__currentLoopData = $imageThumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageThumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($imageThumbnail->id == $album->album_cover_id): ?>
                                    <a href="<?php echo e(route('showcase_album', $album->id)); ?>">
                                        <img src="<?php echo e(asset($imageThumbnail->thumbnail_path)); ?>">
                                        <span class="card-title">
                                            <?php echo e($album->title); ?>

                                        </span>
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="card-content">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode($host . '/showcase/show-album/' . $album->id)); ?>"
                           target="_blank"
                           class="btn-floating waves-effect waves-light blue">
                            <i class="fa fa-facebook"></i>
                        </a>
                        <a href="#!" class="btn-floating waves-effect waves-light blue lighten-2">
                            <i class="fa fa-twitter"></i>
                        </a>
                        <a href="#!" class="btn-floating waves-effect waves-light purple">
                            <i class="fa fa-instagram"></i>
                        </a>
                        <a href="#!"
                           class="btn-floating waves-effect waves-light blue-grey"
                           id="btn-share-link"
                           data-url="<?php echo e($host . '/showcase/show-album/' . $album->id); ?>"
                           onclick="copyLinkAddress(this)">
                            <i class="fa fa-link"></i>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="center">
        <?php echo $__env->make('layouts.paginator.paginator', ['paginator' => $albums], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>