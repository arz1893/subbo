<?php $__env->startSection('content'); ?>
    <div class="center">
        <br/><br/>
        <?php if($user->provider_id != null): ?>
            <img src="https://graph.facebook.com/v2.8/<?php echo e($user->provider_id); ?>/picture?type=large"
                 width="150" height="150" id="profilePicture" class="circle">
        <?php elseif($user->avatar != null): ?>
            <img src="<?php echo e(asset('profile_picture/' . $user->avatar)); ?>"
                 width="150" height="150" id="profilePicture" class="circle">
        <?php else: ?>
            <img src="<?php echo e(asset('images/default/default-avatar.png')); ?>"
                 width="150" height="150" id="profilePicture" class="circle">
        <?php endif; ?>
        <br><br>
        <a href="#!" onclick="$('#select_profile_picture').trigger('click')">
            change profile picture <i class="fa fa-upload"></i>
        </a>
        <?php echo e(Form::open(['action' => 'UserController@changeProfilePicture', 'files' => true, 'id' => 'form_upload_profile_picture'])); ?>

        <?php echo e(Form::hidden('user_id', Auth::user()->id)); ?>

        <input type="file" name="profile_picture" id="select_profile_picture" style="display: none;">
        <?php echo e(Form::close()); ?>

    </div>

    <?php echo e(Form::model($user, ['method' => 'PATCH', 'action' => ['UserController@update', $user->id]])); ?>

        <?php echo $__env->make('layouts.user.user_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>