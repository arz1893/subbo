<div class="container" id="albumform-container">
    <?php echo Form::hidden('user_id', Auth::User()->id); ?>


    <div class="row">
        <div class="input-field">
            <?php echo Form::text('title', null, ['class' => 'validate']); ?>

            <?php echo Form::label('title', 'Album Title'); ?>

        </div>
    </div>

    <div class="row">
        <div class="input-field">
            <?php echo Form::label('description', 'Description'); ?>

            <?php echo Form::textarea('description', null, ['class' => 'materialize-textarea']); ?>

        </div>
    </div>

    <div class="row">
        <div class="">
            <label>
                <i class="fa fa-sort" aria-hidden="true"></i>
                Select Category
            </label> <br/>

            <?php echo Form::select('category_list[]', $categories, null, ['multiple' => 'multiple', 'id' => 'categoryList']); ?>

        </div>
    </div>

    <div class="row">
        <div class="input-field">
            <?php echo Form::label('price', 'Price'); ?>

            <?php echo Form::input('number', 'price', null, ['class' => 'form-control', 'step' => 'any']); ?>

        </div>
    </div>

    <div class="row">
        <div class="col s12 m12 l12">
            <button class="btn-large waves-effect green" style="width: 100%;">
                Update
            </button>
        </div>
    </div>
</div>