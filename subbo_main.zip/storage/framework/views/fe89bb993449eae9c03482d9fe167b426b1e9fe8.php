<?php $__env->startSection('main'); ?>
    <div class="container">
        <h5 class="blue-grey-text">Your purchased album</h5>
        <hr>

        <div class="col s12 m12 l12">
            <?php $counter = 1; ?>
            <table id="order-history-table" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th>No. </th>
                    <th>Image Cover</th>
                    <th>Album Title</th>
                    <th>Price</th>
                    <th>Bought At</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $purchasedAlbums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchasedAlbum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($counter); ?></td>
                            <td>
                                <?php $__currentLoopData = $purchasedAlbum->image_thumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageThumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($purchasedAlbum->album_cover_id == $imageThumbnail->id): ?>
                                        <img src="<?php echo e(asset($imageThumbnail->thumbnail_path)); ?>" width="70" style="margin: 2%">
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><a href="<?php echo e(route('showcase_album', $purchasedAlbum->id)); ?>"><?php echo e($purchasedAlbum->title); ?></a></td>
                            <td><?php echo e("Rp " . number_format( $purchasedAlbum->price , 2 , ',', '.' )); ?></td>
                            <td>
                                <?php echo e($purchasedAlbum->pivot->created_at->format('d-M-Y')); ?>

                            </td>
                        </tr>

                        <?php $counter++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>