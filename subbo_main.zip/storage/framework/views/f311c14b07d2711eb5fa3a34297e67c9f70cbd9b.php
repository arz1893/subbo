<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="center">
                <h4>Create an account</h4>
            </div>
            <div class="center">
                or <a href="<?php echo e(route('login')); ?>">login</a>
            </div>
        </div>
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo e(csrf_field()); ?>


            <div class="input-field<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <label for="name" class="col-md-4 control-label">Name</label>

                <input id="name" type="text" class="browser-default" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                <?php if($errors->has('name')): ?>
                    <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                <?php endif; ?>
            </div>

            <div class="input-field<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                <?php if($errors->has('email')): ?>
                    <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                <?php endif; ?>
            </div>

            <div class="input-field <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <label for="password" class="col-md-4 control-label">Password</label>

                <input id="password" type="password" class="form-control" name="password" required>

                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="input-field">
                <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>
                <input id="password-confirm" type="password" class="validate" name="password_confirmation" required>
            </div>

            <div class="row">
                <div class="left">
                    <div class="col s12">
                        <input type="checkbox" class="filled-in" id="filled-in-box" />
                        <label for="filled-in-box">
                            I agree to <a href="#!">Subbo terms</a>
                        </label>
                    </div>
                </div>
                <div class="right">
                    <div class="col s12">
                        <button type="submit" class="btn blue">
                            Register
                        </button>
                    </div>
                </div>
            </div>
        </form>

        <div class="row center">
            <div class="col s5 m5 l5"><hr></div>
            <div class="col s2 m2 l2">or</div>
            <div class="col s5 m5 l5"><hr></div>
        </div>

        <div class="row">
            <a href="<?php echo e(url('auth/facebook')); ?>" class="btn blue darken-2 white-text col s12">
                <i class="fa fa-facebook" aria-hidden="true"></i> |
                Facebook
            </a>
        </div>
    </div>

    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>