<?php $__env->startSection('main'); ?>
    <div class="center">
        <br/><br/>
        <?php if($user->provider_id != null): ?>
            <img src="https://graph.facebook.com/v2.8/<?php echo e($user->provider_id); ?>/picture?type=large"
                 width="150" height="150" id="profilePicture" class="circle">
        <?php elseif($user->avatar != null): ?>
            <img src="<?php echo e(asset('profile_picture/' . $user->avatar)); ?>"
                 width="150" height="150" id="profilePicture" class="circle">
        <?php else: ?>
            <img src="<?php echo e(asset('images/default/default-avatar.png')); ?>"
                 width="150" height="150" id="profilePicture" class="circle">
        <?php endif; ?>
        <br><br>
        <a href="#!" onclick="$('#select_profile_picture').trigger('click')">
            change profile picture <i class="fa fa-upload"></i>
        </a>
        <?php echo e(Form::open(['action' => 'UserController@changeProfilePicture', 'files' => true, 'id' => 'form_upload_profile_picture'])); ?>

        <?php echo e(Form::hidden('user_id', Auth::user()->id)); ?>

        <input type="file" name="profile_picture" id="select_profile_picture" style="display: none;">
        <?php echo e(Form::close()); ?>

    </div>

    <div class="container">

        <h5 class="blue-grey-text">Name : </h5>
        <div>
            <?php echo e($user->name); ?>

            <a href="#modal_edit_profile">
                <i class="fa fa-pencil-square fa-lg"></i>
            </a>
        </div>

        <h5 class="blue-grey-text">About : </h5>
        <div>
            <?php echo e($user->about); ?>

            <a href="#modal_edit_profile">
                <i class="fa fa-pencil-square fa-lg"></i>
            </a>
        </div>
    </div>

    <!-- Modal Structure -->
    <div id="modal_edit_profile" class="modal modal-fixed-footer">
        <div class="modal-content">
            <h4>Edit your information</h4> <br>
            <?php echo e(Form::model($user, ['method' => 'PATCH', 'action' => ['UserController@update', $user], 'id' => 'user-form'])); ?>

                <?php echo $__env->make('layouts.user.user_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo e(Form::close()); ?>

        </div>
        <div class="modal-footer">
            <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat" onclick="$('#user-form').submit();">Update</a>
            <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Cancel</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>