<?php $__env->startSection('main'); ?>
    <h4 class="center blue-grey-text">Upload Image for album</h4>

    <blockquote class="grey-text">
        Note: make sure all image that you wanted to upload is correct, because you can't undo it after upload
    </blockquote>

    <?php echo Form::open(['action' => ['AlbumController@uploadAllImages'], 'class' => 'dropzone', 'files' => true, 'id'=>'upload-image']); ?>

        <?php echo e(Form::hidden('album_id', $album->id)); ?>

    <?php echo Form::close(); ?>


    <br>
    <div class="row">
        <button
                id="btnSubmitImage"
                type="button"
                class="col s4 m4 offset-s4 offset-m4 btn blue lighten-2">
            Upload Images
        </button>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>