<div class="container">
    <div class="row">
        <div class="input-field">
            <?php echo e(Form::label('name', 'Profile Name : ')); ?>

            <?php echo e(Form::text('name', null, ['class' => 'validate'])); ?>

        </div>
    </div>

    <div class="row">
        <div class="input-field">
            <?php echo e(Form::label('about', 'About you')); ?>

            <?php echo e(Form::textarea('about', null, ['class' => 'materialize-textarea', 'placeholder' => 'Tell about yourself'])); ?>

        </div>
    </div>
</div>