<?php $__env->startSection('main'); ?>

    <h3 class="center grey-text">Your album list</h3>

    <?php if(\Session::has('message')): ?>
        <div class="col s12">
            <div class="chip center green white-text" id="notifChip">
                <?php echo e(Session::get('message')); ?>

                <i class="close material-icons">close</i>
            </div>
        </div>
    <?php endif; ?>

    <div class="row">
        <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col m6 l4">
                <div class="card small">
                    <div class="card-image">
                        <?php if($album->album_cover_id == null): ?>
                            <a href="<?php echo e(route('album.show', $album->id)); ?>">
                                <img src="<?php echo e(asset('images/default/unknown.png')); ?>">

                                <span class="card-title">
                                    <h5><?php echo e($album->title); ?></h5>
                                </span>
                            </a>
                        <?php else: ?>
                            <?php $__currentLoopData = $imageThumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageThumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($imageThumbnail->id == $album->album_cover_id): ?>
                                    <a href="<?php echo e(route('album.show', $album->id)); ?>">
                                        <img src="<?php echo e(asset($imageThumbnail->thumbnail_path)); ?>">

                                        <span class="card-title">
                                            <?php if($album->is_published == 1): ?>
                                                <h5><?php echo e($album->title); ?></h5>
                                            <?php else: ?>
                                                <h5><?php echo e($album->title); ?></h5>
                                            <?php endif; ?>
                                        </span>
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="card-content">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode($host . '/showcase/show-album/' . $album->id)); ?>"
                           target="_blank"
                           class="btn-floating waves-effect waves-light blue">
                            <i class="fa fa-facebook"></i>
                        </a>
                        <a href="#!" class="btn-floating waves-effect waves-light blue lighten-2">
                            <i class="fa fa-twitter"></i>
                        </a>
                        <a href="#!" class="btn-floating waves-effect waves-light purple">
                            <i class="fa fa-instagram"></i>
                        </a>
                        <a href="#!"
                           class="btn-floating waves-effect waves-light blue-grey"
                           id="btn-share-link"
                           data-url="<?php echo e($host . '/showcase/show-album/' . $album->id); ?>"
                           onclick="copyLinkAddress(this)">
                            <i class="fa fa-link"></i>
                        </a>
                        <?php if($album->is_published == 1): ?>
                            <span class="new badge blue right" data-badge-caption="published"></span>
                        <?php else: ?>
                            <span class="new badge red" data-badge-caption="not published"></span>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php echo $__env->make('layouts.popup.popup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>