<?php $__env->startSection('main'); ?>
    <div class="container">
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:site" content="http://subboapp2.esy.es/showcatalog/<?php echo e($album->id); ?>">
        <meta name="twitter:title" content="<?php echo e($album->title); ?>">
        <meta name="twitter:description" content="<?php echo e($album->description); ?>">
        <br/><br/>

        <?php if(\Session::has('message')): ?>
            <div class="col s12">
                <div class="chip center green white-text" id="notifChip">
                    <?php echo e(\Session::get('message')); ?>

                    <i class="close material-icons">close</i>
                </div>
            </div>
        <?php endif; ?>

        

        <?php $__currentLoopData = $imageThumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageThumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($imageThumbnail->id == $album->album_cover_id): ?>
                <div class="col s12 m4 l4">
                    <img src="<?php echo e(asset($imageThumbnail->thumbnail_path)); ?>" width="100%">
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($album->is_published == 0): ?>
            <a
                    href="#popUpSetPublish"
                    data-id="<?php echo e($album->id); ?>"
                    class="col s12 m4 l5 btn green modal-trigger"
                    style="width: 100%;"
                    onclick="setPublishTargetAlbum(this)">
                Publish <i class="fa fa-check" aria-hidden="true"></i>
            </a>
            <a  href="#popUpDeleteAlbum"
                class="btn waves-effect waves-light red modal-trigger"
                data-id="<?php echo e($album->id); ?>"
                style="width: 100%"
                onclick="setDeleteTargetAlbum(this)">
                Delete Album <i class="fa fa-trash"></i>
            </a>
            <a href="<?php echo e(route('album.edit', $album)); ?>"
               class="btn waves-effect waves-light amber modal-trigger"
               style="width: 100%">
                Edit Album <i class="fa fa-pencil-square"></i>
            </a>
        <?php else: ?>
            <a
                    href="#popUpSetUnpublish"
                    data-target="#popUpSetUnpublish"
                    data-id="<?php echo e($album->id); ?>"
                    class="btn waves-effect waves-light blue-grey modal-trigger"
                    style="width: 100%"
                    onclick="setUnpublishTargetAlbum(this)">
                Unpublish <i class="fa fa-power-off" aria-hidden="true"></i>
            </a>
            <a  href="#popUpDeleteAlbum"
                class="btn waves-effect waves-light red modal-trigger"
                data-id="<?php echo e($album->id); ?>"
                style="width: 100%"
                onclick="setDeleteTargetAlbum(this)">
                Delete Album <i class="fa fa-trash"></i>
            </a>
        <?php endif; ?>

        <ul class="collapsible" data-collapsible="accordion">
            <li>
                <div class="collapsible-header"><i class="material-icons">comment</i>Content</div>
                <div class="collapsible-body">
                    <p align="justify"><?php echo nl2br(html_entity_decode($album->description)); ?></p>
                </div>
            </li>
        </ul>

        <h5 class="red-text darken-1">Price : <?php echo e($currency->code . " " .number_format( $album->price , 2 , '.', '.' )); ?></h5>
        <?php if (! ($album->categories->isEmpty())): ?>
            <h5>Category : </h5>
            <ul>
                <?php $__currentLoopData = $album->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="chip">
                        <img src="<?php echo e(asset('images/default/' . $category->image)); ?>">
                        <?php echo e($category->category_name); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>

        <div class="row">

            <?php if($album->is_published == 1): ?>
                <ul class="image-viewer">
                    <?php $__currentLoopData = $imageThumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageThumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <img src="<?php echo e(asset($imageThumbnail->thumbnail_path)); ?>"
                             class="col s4 m2 l2 image-thumbnails" height="75px">
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            <?php else: ?>
                <?php $__currentLoopData = $imageThumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageThumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($imageThumbnail->id == $album->album_cover_id): ?>
                        <div class="col s12 m4 l4">
                            <div class="card">
                                <div class="card-image">
                                    <a href="#!" onclick="Materialize.toast('Already a cover image', 2000)" >
                                        <img src="<?php echo e(asset($imageThumbnail->thumbnail_path)); ?>" height="300">
                                        <span class="card-title">
                                            <h4>Album Cover</h4>
                                        </span>
                                    </a>
                                </div>
                                
                                    
                                        
                                        
                                    
                                
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="col s12 m4 l4">
                            <div class="card">
                                <div class="card-image">
                                    <a href="#popUpConfirm" class="modal-trigger" data-target="#popUpConfirm"
                                       data-id="<?php echo e($imageThumbnail->id); ?>" onClick="selectCover(this);">
                                        <img src="<?php echo e(asset($imageThumbnail->thumbnail_path)); ?>" height="300">
                                    </a>
                                </div>
                                
                                    
                                        
                                        
                                    
                                
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>

        <?php echo $__env->make('layouts.popup.popup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>