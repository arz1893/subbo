<?php $__env->startSection('main'); ?>
    <div class="container">
        <h5 class="blue-grey-text">Download</h5>
        <hr>

        <?php echo e(Form::open(['action' => 'DownloadController@downloadAlbum', 'id' => 'download-request'])); ?>

            <?php echo e(Form::hidden('album_id', $album->id)); ?>

        <?php echo e(Form::close()); ?>


        <div id="download_link" style="display: none">if your download is not starting click
            <a href="#!" onclick="$('#download-request').submit()">here</a>
        </div>
        <div id="countdown">
            Now Downloading in . . . <span id="counter">10</span> second
        </div>
    </div>

    <script type="text/javascript">
        window.onload = function () {
            $('#download_link').hide();
            (function(){
                var counter = 10;

                setInterval(function() {
                    counter--;
                    if (counter >= 0) {
                        span = document.getElementById("counter");
                        span.innerHTML = counter;
                    }
                    // Display 'counter' wherever you want to display it.
                    if (counter === 0) {
                        $('#download_link').removeAttr('style');
                        $('#countdown').hide();
                        $('#download-request').submit();
                        clearInterval(counter);
                    }

                }, 1000);

            })();
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>