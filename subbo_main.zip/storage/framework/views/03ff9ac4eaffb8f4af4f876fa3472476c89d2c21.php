<?php $__env->startSection('main'); ?>
    <div class="container">
        <h5>Peoples who download your album</h5>
        <hr>

        <?php $__currentLoopData = $viewUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul class="collection">
                <li class="collection-item avatar">
                    <?php if($viewUser->provider_id == null): ?>
                        <img src="<?php echo e(asset('profile_picture/' . $viewUser->avatar)); ?>" alt="" class="circle">
                    <?php elseif($viewUser->provider_id != null): ?>
                        <img src="https://graph.facebook.com/v2.8/<?php echo e($viewUser->provider_id); ?>/picture?type=large"
                             id="profilePicture" class="circle">
                    <?php endif; ?>
                    <span class="title"><?php echo e($viewUser->name); ?></span>
                    <p>
                        <a href="#!">
                            View user <i class="fa fa-eye"></i>
                        </a>
                    </p>
                    <a href="#!" class="secondary-content"><i class="fa fa-user-plus"></i></a>
                </li>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>