<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3>You can contact us at</h3>
    </div>


    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>