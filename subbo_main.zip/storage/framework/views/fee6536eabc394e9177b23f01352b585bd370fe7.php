<?php $__env->startSection('main'); ?>
    <div class="container">
        <h4 class="blue-grey-text">Choose your album cover</h4>
        <hr>

        <?php echo e(Form::open(['action' => ['AlbumController@applyAlbumCover', $album]])); ?>

            <?php $__currentLoopData = $imageThumbnails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageThumbnail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="inline">
                    <input value="<?php echo e($imageThumbnail->id); ?>" type="radio" name="image_cover_id" id="<?php echo e($imageThumbnail->id); ?>" class="input-hidden" />
                    <label for="<?php echo e($imageThumbnail->id); ?>">
                        <img src="<?php echo e(asset($imageThumbnail->thumbnail_path)); ?>" />
                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <br><br>
            <?php echo e(Form::submit('Publish album', ['class' => 'btn blue lighten-2', 'style' => 'width: 100%'])); ?>

        <?php echo e(Form::close()); ?>


    </div>
    <?php echo $__env->make('layouts.popup.popup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>